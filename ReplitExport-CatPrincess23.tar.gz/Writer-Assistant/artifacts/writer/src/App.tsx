import { useEffect } from "react";
import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ClerkProvider, SignIn, SignUp, Show, useAuth } from "@clerk/react";
import { publishableKeyFromHost } from "@clerk/react/internal";
import NotFound from "@/pages/not-found";
import { ProProvider } from "@/lib/pro-context";
import { ThemeProvider } from "@/lib/theme";
import { setupGuestId } from "@/lib/guest-id";
import Documents from "@/pages/documents";
import Editor from "@/pages/editor";
import WorldBuilding from "@/pages/world";
import { useCreateDocument, getListDocumentsQueryKey } from "@workspace/api-client-react";

setupGuestId();

const queryClient = new QueryClient();

const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY
);
const isProd = !import.meta.env.DEV;
const clerkProxyUrl = isProd ? window.location.origin + "/api/__clerk" : undefined;
const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || "/" : path;
}

function HomeRedirect() {
  return (
    <>
      <Show when="signed-in"><HomeAuthRedirect /></Show>
      <Show when="signed-out"><Home /></Show>
    </>
  );
}

function HomeAuthRedirect() {
  const [, setLocation] = useLocation();
  useEffect(() => { setLocation("/documents"); }, [setLocation]);
  return null;
}

function Home() {
  return (
    <div className="min-h-[100dvh] bg-background text-foreground flex flex-col relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute -top-[20%] -right-[10%] w-[70%] h-[70%] rounded-full bg-secondary blur-3xl opacity-30" />
        <div className="absolute -bottom-[20%] -left-[10%] w-[60%] h-[60%] rounded-full bg-accent blur-3xl opacity-30" />
      </div>
      <header className="flex items-center justify-between p-6 relative z-10">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-primary text-primary-foreground flex items-center justify-center font-serif font-bold text-lg">W</div>
          <span className="font-serif font-semibold text-xl tracking-tight">WriteAI</span>
        </div>
        <div className="flex gap-4">
          <a href={`${basePath}/sign-in`} className="text-muted-foreground hover:text-foreground font-medium py-2 px-4 transition-colors">Sign In</a>
          <a href={`${basePath}/sign-up`} className="bg-primary text-primary-foreground px-5 py-2 rounded-md font-medium hover:opacity-90 transition-opacity">Get Started</a>
        </div>
      </header>
      <main className="flex-1 flex flex-col items-center justify-center p-6 relative z-10">
        <div className="max-w-3xl w-full text-center space-y-8">
          <h1 className="text-6xl md:text-7xl font-serif font-bold tracking-tight leading-tight">
            A quiet space for <br className="hidden md:block"/>
            <span className="text-muted-foreground italic">serious writers.</span>
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Dark ink on crisp paper. Smart AI that lives at the edges, ready when you need it, invisible when you don't.
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 max-w-2xl mx-auto text-left text-sm">
            {["AI Writing Assist", "Grammar Checker", "World Building", "Version History", "Image Generator", "Book Summarizer", "Export PDF/DOCX", "Dark Mode"].map(f => (
              <div key={f} className="flex items-center gap-2 bg-secondary/50 rounded-lg px-3 py-2 border border-border/50">
                <span className="text-primary">✓</span><span>{f}</span>
              </div>
            ))}
          </div>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <a href={`${basePath}/sign-up`} className="bg-primary text-primary-foreground px-8 py-4 rounded-lg font-medium text-lg hover:opacity-90 transition-all w-full sm:w-auto shadow-lg hover:-translate-y-0.5">
              Start writing for free
            </a>
            <a href={`${basePath}/editor/new`} className="bg-secondary text-secondary-foreground px-8 py-4 rounded-lg font-medium text-lg hover:bg-secondary/80 transition-colors w-full sm:w-auto border border-border">
              Try as Guest
            </a>
          </div>
        </div>
      </main>
    </div>
  );
}

function EditorNewRedirect() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const createDoc = useCreateDocument();
  useEffect(() => {
    createDoc.mutate({ data: { title: "Untitled Document", content: "" } }, {
      onSuccess: (newDoc) => { queryClient.invalidateQueries({ queryKey: getListDocumentsQueryKey() }); setLocation(`/editor/${newDoc.id}`); }
    });
  }, []);
  return <div className="min-h-screen flex items-center justify-center bg-background"><div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" /></div>;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomeRedirect} />
      <Route path="/sign-in" component={() => (
        <div className="flex min-h-[100dvh] items-center justify-center bg-background">
          <SignIn routing="hash" signUpUrl={`${basePath}/sign-up`} />
        </div>
      )} />
      <Route path="/sign-up" component={() => (
        <div className="flex min-h-[100dvh] items-center justify-center bg-background">
          <SignUp routing="hash" signInUrl={`${basePath}/sign-in`} />
        </div>
      )} />
      <Route path="/documents" component={Documents} />
      <Route path="/editor/new" component={EditorNewRedirect} />
      <Route path="/editor/:id" component={Editor} />
      <Route path="/world/:id" component={WorldBuilding} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [, setLocation] = useLocation();
  if (!clerkPubKey) return null;
  return (
    <QueryClientProvider client={queryClient}>
      <ClerkProvider
        publishableKey={clerkPubKey}
        proxyUrl={clerkProxyUrl}
        signInUrl={`${basePath}/sign-in`}
        signUpUrl={`${basePath}/sign-up`}
        routerPush={(to) => setLocation(stripBase(to))}
        routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
      >
        <ThemeProvider>
          <TooltipProvider>
            <ProProvider>
              <WouterRouter base={basePath}>
                <Router />
              </WouterRouter>
              <Toaster />
            </ProProvider>
          </TooltipProvider>
        </ThemeProvider>
      </ClerkProvider>
    </QueryClientProvider>
  );
}

export default App;
