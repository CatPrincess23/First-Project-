import { Router } from "express";
import OpenAI from "openai";
import { AiSuggestBody, AiGrammarCheckBody, AiGenerateImageBody, AiSummarizeBody, AiGeneratePrologueBody } from "@workspace/api-zod";

const router = Router();

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// POST /api/ai/suggest
router.post("/suggest", async (req, res) => {
  const parse = AiSuggestBody.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: "Invalid input" });
  const { text, type, context } = parse.data;
  const prompts: Record<string, string> = {
    improve: `Improve the following text to make it clearer, more engaging, and better written. Return only the improved text:\n\n${text}`,
    expand: `Expand the following text with more detail and depth. Return only the expanded text:\n\n${text}`,
    shorten: `Shorten the following text while keeping the key ideas. Return only the shortened text:\n\n${text}`,
    rephrase: `Rephrase the following text in a different way. Return only the rephrased text:\n\n${text}`,
    continue: `Continue writing naturally from the following text. Return only the continuation (not the original):\n\n${text}`,
  };
  const systemMsg = context ? `You are a skilled writing assistant. Context: ${context.slice(0, 500)}` : "You are a skilled writing assistant.";
  const completion = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{ role: "system", content: systemMsg }, { role: "user", content: prompts[type] || prompts.improve }],
    max_tokens: 1000,
  });
  res.json({ suggestion: completion.choices[0]?.message?.content?.trim() || "" });
});

// POST /api/ai/grammar
router.post("/grammar", async (req, res) => {
  const parse = AiGrammarCheckBody.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: "Invalid input" });
  const { text } = parse.data;
  const completion = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      { role: "system", content: `You are a grammar and spelling checker. Analyze the text and return a JSON object with:\n- "errors": array of { "message": string, "offset": number, "length": number, "type": "grammar"|"spelling"|"style", "suggestion": string|null }\n- "correctedText": the full corrected version\nReturn ONLY valid JSON, no markdown.` },
      { role: "user", content: `Check this text:\n\n${text}` },
    ],
    max_tokens: 2000,
    response_format: { type: "json_object" },
  });
  const raw = completion.choices[0]?.message?.content || '{"errors":[],"correctedText":""}';
  let result;
  try { result = JSON.parse(raw); } catch { result = { errors: [], correctedText: text }; }
  res.json({ errors: result.errors || [], correctedText: result.correctedText || text });
});

// POST /api/ai/image
router.post("/image", async (req, res) => {
  const parse = AiGenerateImageBody.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: "Invalid input" });
  const { prompt, size } = parse.data;
  const response = await openai.images.generate({
    model: "dall-e-3",
    prompt,
    n: 1,
    size: (size || "1024x1024") as any,
    response_format: "b64_json",
  });
  res.json({ b64_json: response.data[0]?.b64_json || "" });
});

// POST /api/ai/summarize
router.post("/summarize", async (req, res) => {
  const parse = AiSummarizeBody.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: "Invalid input" });
  const { text, title } = parse.data;
  const completion = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      { role: "system", content: "You are a literary assistant specializing in book and manuscript summaries. Create clear, engaging summaries that capture the essence of the work." },
      { role: "user", content: `Please provide a concise summary of the following manuscript${title ? ` titled "${title}"` : ""}. Identify key themes, plot points, characters, and the overall arc:\n\n${text.slice(0, 8000)}` },
    ],
    max_tokens: 600,
  });
  res.json({ summary: completion.choices[0]?.message?.content?.trim() || "" });
});

// POST /api/ai/prologue
router.post("/prologue", async (req, res) => {
  const parse = AiGeneratePrologueBody.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: "Invalid input" });
  const { text, title } = parse.data;
  const completion = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      { role: "system", content: "You are a master storyteller and author. Write compelling prologues that hook readers immediately and set the tone for the story." },
      { role: "user", content: `Based on the following manuscript content${title ? ` from a book titled "${title}"` : ""}, write a captivating prologue that sets the stage for the story. The prologue should be mysterious, atmospheric, and draw readers in. Write it as actual narrative prose:\n\n${text.slice(0, 6000)}` },
    ],
    max_tokens: 800,
  });
  res.json({ prologue: completion.choices[0]?.message?.content?.trim() || "" });
});

export default router;
